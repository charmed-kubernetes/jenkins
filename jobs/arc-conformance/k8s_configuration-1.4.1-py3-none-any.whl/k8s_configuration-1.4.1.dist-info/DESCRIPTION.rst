Microsoft Azure CLI 'k8s-configuration' Extension
==========================================

This package is for the 'k8s-configuration' extension.
i.e. 'az k8s-configuration'

### How to use ###
Install this extension using the below CLI command
```
az extension add --name k8s-configuration
```

### Included Features

#### Flux Configuration (Flux v2):
Flux Configuration (Flux v1) Configuration: [more info](https://docs.microsoft.com/en-us/azure/kubernetessconfiguration/)\
*Examples:*

##### Create a Flux Configuration (Flux v2)
```
az k8s-configuration create flux \
    --resource-group groupName \
    --cluster-name clusterName \
    --cluster-type clusterType \
    --name configurationName \
    --namespace configurationNamespace \
    --scope cluster
    --kind git \
    --url https://github.com/Azure/arc-k8s-demo \
    --branch main \
    --kustomization name=my-kustomization 
```

##### Get a Flux Configuration (Flux v2)
```
az k8s-configuration flux show \
    --resource-group groupName \
    --cluster-name clusterName \
    --cluster-type clusterType \
    --name configurationName
```

##### Delete a Flux Configuration (Flux v2)
```
az k8s-configuration flux delete \
    --resource-group groupName \
    --cluster-name clusterName \
    --cluster-type clusterType \
    --name configurationName
```

##### List all Flux Configuration (Flux v2) on a cluster
```
az k8s-configuration flux list \
    --resource-group groupName \
    --cluster-name clusterName \
    --cluster-type clusterType
```

#### Source Control Configuration (Flux v1):
Source Control Configuration (Flux v1) Configuration: [more info](https://docs.microsoft.com/en-us/azure/kubernetessconfiguration/)\
*Examples:*

##### Create a Source Control Configuration (Flux v1)
```
az k8s-configuration create \
    --resource-group groupName \
    --cluster-name clusterName \
    --cluster-type clusterType \
    --name configurationName \
    --operator-instance-name operatorInstanceName \
    --operator-namespace operatorNamespace \
    --repository-url githubRepoUrl \
    --operator-params operatorParameters \
    --enable-helm-operator \
    --helm-operator-version chartVersion \
    --helm-operator-params chartParameters
```

##### Get a Source Control Configuration (Flux v1)
```
az k8s-configuration show \
    --resource-group groupName \
    --cluster-name clusterName \
    --cluster-type clusterType \
    --name configurationName
```

##### Delete a Source Control Configuration (Flux v1)
```
az k8s-configuration delete \
    --resource-group groupName \
    --cluster-name clusterName \
    --cluster-type clusterType \
    --name configurationName
```

##### Update a Source Control Configuration (Flux v1)
```
az k8s-configuration create \
    --resource-group groupName \
    --cluster-name clusterName \
    --cluster-type clusterType \
    --name configurationName \
    --repository-url githubRepoUrl \
    --operator-params operatorParameters \
    --enable-helm-operator \
    --helm-operator-version chartVersion \
    --helm-operator-params chartParameters
```

##### List all Source Control Configuration (Flux v1) on a cluster
```
az k8s-configuration list \
    --resource-group groupName \
    --cluster-name clusterName \
    --cluster-type clusterType
```

If you have issues, please give feedback by opening an issue at https://github.com/Azure/azure-cli-extensions/issues.

.. :changelog:

Release History
===============

1.4.1
++++++++++++++++++
* [BREAKING CHANGE] `--access-key` changed to `--bucket-access-key`
* [BREAKING CHANGE] `--secret-key` changed to `--bucket-secret-key`
* [BREAKING CHANGE] `--insecure` changed to `--bucket-insecure`
* Fix help text for bucket parameters

1.4.0
++++++++++++++++++
* Add `--kind bucket` for creation of S3 bucket as source for fluxConfigurations

1.3.0
++++++++++++++++++
* Add `deployed-object` command group for showing deployed Flux objects from configuration
* Show extension error when `microsoft.flux` extension is in a failed state

1.2.0
++++++++++++++++++
* Add Flux v2 support with command subgroups
* Add update support to Flux v2 resources

1.1.1
++++++++++++++++++
* Enable helm-operator chart version 1.4.0

1.1.0
++++++++++++++++++
* Update sourceControlConfiguration resource models to Track2

1.0.1
++++++++++++++++++
* Add provider registration check

1.0.0
++++++++++++++++++
* Support api-version 2021-03-01
* Update helm operator parameter aliases
* Migrate from k8sconfiguration to k8s-configuration

